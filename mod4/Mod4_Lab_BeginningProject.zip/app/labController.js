app.controller('labController', [
    '$scope',
    function ($scope) {
    }
]);